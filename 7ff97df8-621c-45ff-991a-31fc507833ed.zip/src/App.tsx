import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { FeaturesSection } from './components/FeaturesSection';
import { CapabilitiesSection } from './components/CapabilitiesSection';
import { ComingSoonSection } from './components/ComingSoonSection';
import { Footer } from './components/Footer';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { DashboardHome } from './pages/dashboard/DashboardHome';
import { ProductsPage } from './pages/dashboard/ProductsPage';
import { SubscriptionsPage } from './pages/dashboard/SubscriptionsPage';
import { ContactPage } from './pages/dashboard/ContactPage';
import { AccountPage } from './pages/dashboard/AccountPage';
import { DocumentationPage } from './pages/dashboard/DocumentationPage';
function HomePage() {
  return <>
      <Header />
      <HeroSection />
      <FeaturesSection />
      <CapabilitiesSection />
      <ComingSoonSection />
      <Footer />
    </>;
}
export function App() {
  return <BrowserRouter>
      <div className="min-h-screen font-sans text-gray-900">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/signup" element={<SignupPage />} />
          <Route path="/dashboard" element={<DashboardHome />} />
          <Route path="/dashboard/products" element={<ProductsPage />} />
          <Route path="/dashboard/subscriptions" element={<SubscriptionsPage />} />
          <Route path="/dashboard/contact" element={<ContactPage />} />
          <Route path="/dashboard/account" element={<AccountPage />} />
          <Route path="/dashboard/documentation" element={<DocumentationPage />} />
        </Routes>
      </div>
    </BrowserRouter>;
}