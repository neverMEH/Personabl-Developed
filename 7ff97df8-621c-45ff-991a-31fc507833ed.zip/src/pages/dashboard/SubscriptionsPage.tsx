import React, { useState } from 'react';
import { DashboardLayout } from '../../components/dashboard/DashboardLayout';
import { Loader2Icon } from 'lucide-react';
export function SubscriptionsPage() {
  const [isLoading, setIsLoading] = useState(true);
  return <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Subscription Management</h1>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="relative w-full" style={{
          height: '700px'
        }}>
            {isLoading && <div className="absolute inset-0 flex items-center justify-center bg-white">
                <Loader2Icon className="w-8 h-8 text-indigo-600 animate-spin" />
              </div>}
            <iframe src="https://billing.stripe.com/p/login/test_3cIdR90dJ1Tf1m72rCcEw00" className="w-full h-full" onLoad={() => setIsLoading(false)} style={{
            border: 'none'
          }} title="Stripe Customer Portal" />
          </div>
        </div>
      </div>
    </DashboardLayout>;
}